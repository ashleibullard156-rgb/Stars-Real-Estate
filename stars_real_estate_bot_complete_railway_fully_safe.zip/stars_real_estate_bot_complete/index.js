
/**
 * Crash-safe Railway Discord Bot
 * Auto-restart handled by Railway worker
 */

function log(message, error = null) {
  const time = new Date().toISOString();
  if (error) {
    console.error(`[${time}] ${message}`, error);
  } else {
    console.log(`[${time}] ${message}`);
  }
}

process.on('unhandledRejection', (reason) => {
  log('Unhandled Promise Rejection', reason);
  process.exit(1);
});

process.on('uncaughtException', (err) => {
  log('Uncaught Exception', err);
  process.exit(1);
});

log("Bot process starting...");


require('dotenv').config();
const { Client, GatewayIntentBits, SlashCommandBuilder, Routes } = require('discord.js');
const { REST } = require('@discordjs/rest');

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

// Commands
const commands = [
    new SlashCommandBuilder().setName('contract_purchase').setDescription('Property Purchase Contract'),
    new SlashCommandBuilder().setName('contract_membership').setDescription('Membership Contract'),
    new SlashCommandBuilder().setName('contract_transfer').setDescription('Property Transfer Contract'),
    
    new SlashCommandBuilder()
        .setName('membership_format')
        .setDescription('Generate Membership Record Format')
        .addStringOption(o => o.setName('discord').setDescription('Discord Tag').setRequired(true))
        .addStringOption(o => o.setName('rpname').setDescription('RP Name').setRequired(true))
        .addStringOption(o => o.setName('membership').setDescription('Membership Level').setRequired(true))
        .addStringOption(o => o.setName('date').setDescription('Date Activated').setRequired(true)),

    new SlashCommandBuilder()
        .setName('sale_format')
        .setDescription('Generate Property Sale Format')
        .addStringOption(o => o.setName('soldby').setDescription('Sold by').setRequired(true))
        .addStringOption(o => o.setName('agentrp').setDescription('Agents RP Name').setRequired(true))
        .addStringOption(o => o.setName('agentdiscord').setDescription('Agents Discord').setRequired(true))
        .addStringOption(o => o.setName('saledate').setDescription('Sale Date').setRequired(true))
        .addStringOption(o => o.setName('ownerdiscord').setDescription('Owners Discord').setRequired(true))
        .addStringOption(o => o.setName('ownerrp').setDescription('Owners RP Name').setRequired(true))
        .addStringOption(o => o.setName('saleprice').setDescription('Sale Price').setRequired(true))
        .addStringOption(o => o.setName('address').setDescription('Property Address').setRequired(true))
        .addStringOption(o => o.setName('propertytype').setDescription('Property Type').setRequired(true))
        .addStringOption(o => o.setName('number').setDescription('Number (AOP MAP)').setRequired(true))
        .addStringOption(o => o.setName('photos').setDescription('Property Photos (3)').setRequired(true)),

    new SlashCommandBuilder()
        .setName('transfer_format')
        .setDescription('Generate Property Transfer Format')
        .addStringOption(o => o.setName('transfer').setDescription('Type of transfer').setRequired(true))
        .addStringOption(o => o.setName('transferee').setDescription('Transferee').setRequired(true))
        .addStringOption(o => o.setName('oldownerdiscord').setDescription('Old Owners Discord').setRequired(true))
        .addStringOption(o => o.setName('oldownerrp').setDescription('Old Owners RP Name').setRequired(true))
        .addStringOption(o => o.setName('newownerdiscord').setDescription('New Owners Discord').setRequired(true))
        .addStringOption(o => o.setName('newownerrp').setDescription('New Owners RP Name').setRequired(true))
        .addStringOption(o => o.setName('agentdiscord').setDescription('Agents Discord').setRequired(true))
        .addStringOption(o => o.setName('agentrp').setDescription('Agents RP Name').setRequired(true))
        .addStringOption(o => o.setName('fee').setDescription('Transfer Fee Cost').setRequired(true))
        .addStringOption(o => o.setName('originalprice').setDescription('Original Sale Price').setRequired(true))
        .addStringOption(o => o.setName('date').setDescription('Transfer Date').setRequired(true))
        .addStringOption(o => o.setName('address').setDescription('Property Address').setRequired(true))
        .addStringOption(o => o.setName('propertytype').setDescription('Property Type').setRequired(true))
        .addStringOption(o => o.setName('number').setDescription('Number (AOP MAP)').setRequired(true))
        .addStringOption(o => o.setName('notes').setDescription('Notes').setRequired(false))
        .addStringOption(o => o.setName('photos').setDescription('Property Photos (3)').setRequired(true))
].map(c => c.toJSON());

// Register commands
const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commands })
    .then(() => console.log('Commands registered.'))
    .catch(console.error);

client.on('ready', () => console.log(`${client.user.tag} is online!`));

client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;

    // Contract commands
    if (interaction.commandName === 'contract_purchase') {
        await interaction.reply(`**PROPERTY PURCHASE CONTRACT**\n\nSeller: Stars Real Estate\nBuyer: [Insert Client's Roleplay Name]\nProperty Address: [Insert Postal]\nPurchase Price: [Insert Purchase Price]\n...`);
    }

    if (interaction.commandName === 'contract_membership') {
        await interaction.reply(`**MEMBERSHIP CONTRACT**\n\nCompany: Stars Real Estate\nMember: [Insert Client’s Roleplay Name]\nMembership Level: ...`);
    }

    if (interaction.commandName === 'contract_transfer') {
        await interaction.reply(`**PROPERTY TRANSFER CONTRACT**\n\nProperty Address: [Insert Postal and Street]\nSale Price: [Insert Purchase Price]\nTransfer Fee: ...`);
    }

    // Format commands
    if (interaction.commandName === 'membership_format') {
        const discordUser = interaction.options.getString('discord');
        const rpName = interaction.options.getString('rpname');
        const membership = interaction.options.getString('membership');
        const date = interaction.options.getString('date');
        await interaction.reply(`Membership Record\nDiscord: ${discordUser}\nRP Name: ${rpName}\nMembership: ${membership}\nDate Activated: ${date}`);
    }

    if (interaction.commandName === 'sale_format') {
        const soldBy = interaction.options.getString('soldby');
        const agentRP = interaction.options.getString('agentrp');
        const agentDiscord = interaction.options.getString('agentdiscord');
        const saleDate = interaction.options.getString('saledate');
        const ownerDiscord = interaction.options.getString('ownerdiscord');
        const ownerRP = interaction.options.getString('ownerrp');
        const salePrice = interaction.options.getString('saleprice');
        const address = interaction.options.getString('address');
        const propertyType = interaction.options.getString('propertytype');
        const number = interaction.options.getString('number');
        const photos = interaction.options.getString('photos');

        await interaction.reply(`Sold | Stars Real Estate\nSold by: ${soldBy}\nAgents RP Name: ${agentRP}\nAgents Discord: ${agentDiscord}\nSale Date: ${saleDate}\nOwners Discord: ${ownerDiscord}\nOwners RP Name: ${ownerRP}\nSale Price: ${salePrice}\nAddress: ${address}\nProperty Type: ${propertyType}\nNumber: ${number}\nProperty Photos (3): ${photos}`);
    }

    if (interaction.commandName === 'transfer_format') {
        const transfer = interaction.options.getString('transfer');
        const transferee = interaction.options.getString('transferee');
        const oldOwnerDiscord = interaction.options.getString('oldownerdiscord');
        const oldOwnerRP = interaction.options.getString('oldownerrp');
        const newOwnerDiscord = interaction.options.getString('newownerdiscord');
        const newOwnerRP = interaction.options.getString('newownerrp');
        const agentDiscord = interaction.options.getString('agentdiscord');
        const agentRP = interaction.options.getString('agentrp');
        const fee = interaction.options.getString('fee');
        const originalPrice = interaction.options.getString('originalprice');
        const date = interaction.options.getString('date');
        const address = interaction.options.getString('address');
        const propertyType = interaction.options.getString('propertytype');
        const number = interaction.options.getString('number');
        const notes = interaction.options.getString('notes') || 'None';
        const photos = interaction.options.getString('photos');

        await interaction.reply(`Property Transfer | Stars Real Estate\nTransfer: ${transfer}\nTransferee: ${transferee}\nOld Owners Discord: ${oldOwnerDiscord}\nOld Owners RP Name: ${oldOwnerRP}\nNew Owners Discord: ${newOwnerDiscord}\nNew Owners RP Name: ${newOwnerRP}\nAgents Discord: ${agentDiscord}\nAgents RP Name: ${agentRP}\nTransfer Fee Cost: ${fee}\nOriginal Sale Price: ${originalPrice}\nTransfer Date: ${date}\nAddress: ${address}\nProperty Type: ${propertyType}\nNumber: ${number}\nNotes: ${notes}\nProperty Photos (3): ${photos}`);
    }
});

client.login(process.env.DISCORD_TOKEN);

